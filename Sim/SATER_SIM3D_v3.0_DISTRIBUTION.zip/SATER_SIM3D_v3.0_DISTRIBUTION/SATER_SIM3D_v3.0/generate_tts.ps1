# SATER SIM3D - Generateur de voix PCO via Windows SAPI
# F1GBD / ADRASEC 77
# Usage: powershell -ExecutionPolicy Bypass -File generate_tts.ps1

param([string]$MissionPath = "")

if ($MissionPath -eq "") {
    # Chercher automatiquement le dossier mission
    $candidates = @(
        "$env:USERPROFILE\Documents\Arma 3 - Other Profiles\$env:USERNAME\missions\SaterSim.Altis",
        "D:\SteamLibrary\steamapps\common\Arma 3\Missions\SaterSim.Altis",
        "C:\Program Files (x86)\Steam\steamapps\common\Arma 3\Missions\SaterSim.Altis"
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { $MissionPath = $c; break }
    }
}

if (-not (Test-Path $MissionPath)) {
    Write-Host "ERREUR: Dossier mission non trouve: $MissionPath" -ForegroundColor Red
    exit 1
}

Write-Host "=== SATER SIM3D - Generation voix PCO ===" -ForegroundColor Cyan
Write-Host "Dossier: $MissionPath" -ForegroundColor White

# Initialiser SAPI
try {
    $sapi = New-Object -ComObject SAPI.SpVoice
} catch {
    Write-Host "ERREUR SAPI: $_" -ForegroundColor Red
    exit 1
}

# Choisir voix francaise
$voices = $sapi.GetVoices()
$frVoice = $null
for ($i = 0; $i -lt $voices.Count; $i++) {
    $desc = $voices.Item($i).GetDescription()
    Write-Host "  Voix [$i]: $desc"
    if ($desc -match "Hortense|Julie|French|fran") {
        $frVoice = $voices.Item($i)
        Write-Host "    -> Voix francaise selectionnee" -ForegroundColor Green
    }
}
if ($frVoice) { $sapi.Voice = $frVoice }
$sapi.Rate = 1

$messages = @(
    @{ file="pco_start.wav";       text="Sataire, ici le PC Ops. Debut de la mission. Rejoignez le point de depart sur votre carte." },
    @{ file="pco_r1.wav";          text="Bien recu. Deplacez vous au point Romeo Un et donnez un relevement." },
    @{ file="pco_r2.wav";          text="Triangulation en cours. Allez au point Romeo Deux pour relevement complementaire." },
    @{ file="pco_r3.wav";          text="Les relevements convergent. Approchez du point Romeo Trois." },
    @{ file="pco_r4.wav";          text="Bien recu. Allez au signal. Signalez quand le signal est maximum." },
    @{ file="pco_close.wav";       text="Vous etes tres proche. Passez en recherche fine. Signalez la balise." },
    @{ file="pco_signal_fort.wav"; text="Signal fort. Maintenez le cap et approchez lentement." },
    @{ file="pco_found.wav";       text="Balise localisee. Mission Sataire terminee avec succes." }
)

$stream = New-Object -ComObject SAPI.SpFileStream
$ok = 0
foreach ($msg in $messages) {
    $path = Join-Path $MissionPath $msg.file
    Write-Host "-> $($msg.file) ..." -NoNewline
    try {
        $stream.Open($path, 3, $false)
        $sapi.AudioOutputStream = $stream
        $sapi.Speak($msg.text, 0)
        $stream.Close()
        $kb = [math]::Round((Get-Item $path).Length / 1024, 1)
        Write-Host " OK ($kb Ko)" -ForegroundColor Green
        $ok++
    } catch {
        Write-Host " ERREUR: $_" -ForegroundColor Red
        try { $stream.Close() } catch {}
    }
}

Write-Host ""
Write-Host "$ok/8 fichiers generes." -ForegroundColor Cyan
