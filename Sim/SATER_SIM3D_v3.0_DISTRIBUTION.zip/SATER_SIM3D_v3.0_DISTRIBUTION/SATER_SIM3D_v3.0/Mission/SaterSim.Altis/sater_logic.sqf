/*
    SATER_LOGIC.SQF v3 - Mission SATER autonome pour ARMA III
    F1GBD / ADRASEC 77

    Architecture standalone :
      - Plus de SATER_Sim3D.py externe
      - Plus d'arma_bridge.py
      - Tout le moteur SATER tourne dans sater_code/__init__.py (Pythia)
      - La mission est generee automatiquement au restart
      - Coordonnees GPS de la map ARMA utilisees directement

    Fonctions Pythia appelees :
      sater_code.heartbeat()
      sater_code.init_mission(map, lat, lon, px, py) -> [bal_ax, bal_ay, sta_ax, sta_ay, tx]
      sater_code.tick(px, py, yaw, found, nax, nay) -> [rssi, bearing, dist_m, s_level, status]
      sater_code.add_bearing(px, py, yaw)           -> [next_ax, next_ay, msg, bc]
      sater_code.get_bearings()                     -> [n, lat,lon,ax,ay,az,label, ...]
      sater_code.declare_found(px, py)              -> [dist_m, appr, bal_ax, bal_ay]
      sater_code.get_mission_status()               -> [active, bc, dist_m, rssi, bearing, bal_ax, bal_ay, op_ax, op_ay, found]
*/

// =========================================================================
// Configuration
// =========================================================================

// Origine GPS de la map (Altis par defaut)
// Altis : 39.0N 22.6E
// Pour changer de map : modifier ces deux valeurs
private _originLat = 39.0;
private _originLon = 22.6;
private _mapName   = "Altis";

// Seuils
private _foundRadius  = 15;   // metres - rayon detection balise
private _hudRefresh   = 0.25; // secondes - rafraichissement HUD
private _heartbeatS   = 1.0;

// Rendre l'origine accessible aux autres scripts
SATER_ORIGIN_LAT = _originLat;
SATER_ORIGIN_LON = _originLon;

// =========================================================================
// Fonctions geodesiques (pour la carte)
// =========================================================================

fnc_armaToGPS = {
    params ["_ax", "_ay"];
    private _lat = SATER_ORIGIN_LAT + (_ay / 111320.0);
    private _cos = cos(SATER_ORIGIN_LAT * (pi / 180.0));
    private _lon = SATER_ORIGIN_LON + (_ax / (111320.0 * _cos));
    [_lat, _lon]
};

fnc_gpsToArma = {
    params ["_lat", "_lon"];
    private _cos = cos(SATER_ORIGIN_LAT * (pi / 180.0));
    private _ax  = (_lon - SATER_ORIGIN_LON) * 111320.0 * _cos;
    private _ay  = (_lat - SATER_ORIGIN_LAT) * 111320.0;
    [_ax, _ay]
};

// =========================================================================
// Fonctions HUD
// =========================================================================

fnc_drawHUD = {
    params ["_rssi", "_bearing", "_distM", "_sLevel", "_status", "_bc"];

    // Supprimer ancien HUD
    {
        private _old = uiNamespace getVariable [_x, controlNull];
        if (!isNull _old) then { ctrlDelete _old; };
    } forEach ["SATER_HUD_CAP", "SATER_HUD_RSSI", "SATER_HUD_INFO", "SATER_HUD_GPS"];

    private _display = findDisplay 46;

    // Couleur selon signal
    private _col = [1, 0.2, 0.1, 1];
    if (_rssi > 0.15) then { _col = [1.0, 0.65, 0.0, 1]; };
    if (_rssi > 0.35) then { _col = [1.0, 0.90, 0.0, 1]; };
    if (_rssi > 0.60) then { _col = [0.0, 1.0,  0.3, 1]; };

    // Calcul position GPS - drone si mode drone, joueur sinon
    private _gpsObj = player;
    {
        if (typeOf _x == "B_UAV_01_F") then {
            if (cameraOn == _x || vehicle cameraOn == _x) then { _gpsObj = _x; };
        };
    } forEach vehicles;
    private _pos = getPosATL _gpsObj;
    private _gpsArr = [_pos select 0, _pos select 1] call fnc_armaToGPS;
    private _gLat = _gpsArr select 0;
    private _gLon = _gpsArr select 1;
    // Latitude DMS
    private _latD = floor abs _gLat;
    private _latMf = (abs _gLat - _latD) * 60;
    private _latM = floor _latMf;
    private _latS = round ((_latMf - _latM) * 60);
    private _latH = if (_gLat >= 0) then {"N"} else {"S"};
    // Longitude DMS
    private _lonD = floor abs _gLon;
    private _lonMf = (abs _gLon - _lonD) * 60;
    private _lonM = floor _lonMf;
    private _lonS = round ((_lonMf - _lonM) * 60);
    private _lonH = if (_gLon >= 0) then {"E"} else {"W"};
    private _gpsStr = format ["%1deg %2min %3sec %4  %5deg %6min %7sec %8",
        _latD, _latM, _latS, _latH,
        _lonD, _lonM, _lonS, _lonH];

    // === HUD compact - 2 lignes + GPS ===
    // Disposition : [CAP deg | S-metre RSSI] / [Info relev] / [GPS]

    // Mode DRONE
    private _hudDrone = false;
    {
        if (typeOf _x == "B_UAV_01_F") then {
            if (cameraOn == _x || vehicle cameraOn == _x) then { _hudDrone = true; };
        };
    } forEach vehicles;
    private _modeLabel = if (_hudDrone) then {" [DRONE]"} else {""};

    // RSSI barre
    private _bars   = 14;
    private _filled = round (_rssi * _bars);
    private _bar    = "";
    for "_i" from 1 to _filled           do { _bar = _bar + "#"; };
    for "_i" from (_filled + 1) to _bars do { _bar = _bar + "."; };

    // Distance
    private _distStr = if (_distM < 1000) then { format ["%1m", round _distM] }
                       else { format ["%1km", round(_distM/100)/10] };

    // Positions safeZone - centre haut, compact
    private _sx = safeZoneX + safeZoneW * 0.25;
    private _sy = safeZoneY;
    private _sw = safeZoneW * 0.50;
    private _sh = safeZoneH;

    // LIGNE 1A : CAP (gauche 60%)
    private _ctrlCap = _display ctrlCreate ["RscText", -1];
    _ctrlCap ctrlSetPosition        [_sx, _sy, _sw * 0.55, _sh * 0.070];
    _ctrlCap ctrlSetText            format ["%1 deg", round _bearing];
    _ctrlCap ctrlSetTextColor       [1.0, 1.0, 1.0, 1.0];
    _ctrlCap ctrlSetBackgroundColor [0, 0, 0, 0.85];
    _ctrlCap ctrlSetFontHeight      0.085;
    _ctrlCap ctrlCommit 0;
    uiNamespace setVariable ["SATER_HUD_CAP", _ctrlCap];

    // LIGNE 1B : RSSI (droite 40%)
    private _ctrlRssi = _display ctrlCreate ["RscText", -1];
    _ctrlRssi ctrlSetPosition        [_sx + _sw * 0.56, _sy, _sw * 0.44, _sh * 0.070];
    _ctrlRssi ctrlSetText            format ["S%1 [%2]", _sLevel, _bar];
    _ctrlRssi ctrlSetTextColor       _col;
    _ctrlRssi ctrlSetBackgroundColor [0, 0, 0, 0.85];
    _ctrlRssi ctrlSetFontHeight      0.065;
    _ctrlRssi ctrlCommit 0;
    uiNamespace setVariable ["SATER_HUD_RSSI", _ctrlRssi];

    // LIGNE 2 : Info relevement
    private _ctrlInfo = _display ctrlCreate ["RscText", -1];
    _ctrlInfo ctrlSetPosition        [_sx, _sy + _sh * 0.070, _sw, _sh * 0.052];
    _ctrlInfo ctrlSetText            format ["ELT 121.5 R%1 %2%3", _bc, _distStr, _modeLabel];
    _ctrlInfo ctrlSetTextColor       [0.9, 0.9, 0.9, 1.0];
    _ctrlInfo ctrlSetBackgroundColor [0, 0, 0, 0.85];
    _ctrlInfo ctrlSetFontHeight      0.058;
    _ctrlInfo ctrlCommit 0;
    uiNamespace setVariable ["SATER_HUD_INFO", _ctrlInfo];

    // LIGNE 3 : GPS DMS
    private _ctrlGps = _display ctrlCreate ["RscText", -1];
    _ctrlGps ctrlSetPosition        [_sx, _sy + _sh * 0.122, _sw, _sh * 0.048];
    _ctrlGps ctrlSetText            format ["GPS: %1", _gpsStr];
    _ctrlGps ctrlSetTextColor       [0.5, 1.0, 0.8, 1.0];
    _ctrlGps ctrlSetBackgroundColor [0, 0, 0, 0.85];
    _ctrlGps ctrlSetFontHeight      0.054;
    _ctrlGps ctrlCommit 0;
    uiNamespace setVariable ["SATER_HUD_GPS", _ctrlGps];
};

// Notification sonore PCO via playSound3D chemin mission
fnc_pcoSound = {
    params ["_file"];
    if (_file != "") then {
        // playSound3D avec chemin relatif mission - methode la plus fiable
        private _fullPath = getMissionPath _file;
        playSound3D [_fullPath, player, false, getPosATL player, 1.5, 1.0, 0];
    };
};

// Fonction pour afficher un message en haut a gauche (lisible sur herbe)
fnc_saterMsg = {
    params ["_msg", "_col"];
    if (isNil "_col") then { _col = [1.0, 1.0, 0.8, 1.0]; };
    private _old = uiNamespace getVariable ["SATER_MSG_CTRL", controlNull];
    if (!isNull _old) then { ctrlDelete _old; };
    private _display = findDisplay 46;
    private _ctrl = _display ctrlCreate ["RscText", -1];
    _ctrl ctrlSetPosition        [0.01, 0.02, 0.55, 0.055];
    _ctrl ctrlSetText            _msg;
    _ctrl ctrlSetTextColor       _col;
    _ctrl ctrlSetBackgroundColor [0, 0, 0, 0.85];
    _ctrl ctrlSetFontHeight      0.040;
    _ctrl ctrlCommit 0;
    uiNamespace setVariable ["SATER_MSG_CTRL", _ctrl];
    // Effacer apres 8 secondes
    [_ctrl] spawn {
        params ["_c"];
        sleep 8;
        if (!isNull _c) then { ctrlDelete _c; };
        uiNamespace setVariable ["SATER_MSG_CTRL", controlNull];
    };
};

fnc_createBaliseMarker = {
    params ["_ax", "_ay"];
    deleteMarker "SATER_bal";
    createMarker ["SATER_bal", [_ax, _ay, 0]];
    "SATER_bal" setMarkerType  "mil_triangle";
    "SATER_bal" setMarkerColor "ColorOrange";
    "SATER_bal" setMarkerText  "ELT";
    "SATER_bal" setMarkerSize  [0.8, 0.8];
    deleteMarker "SATER_bal_zone";
    createMarker ["SATER_bal_zone", [_ax, _ay, 0]];
    "SATER_bal_zone" setMarkerType  "mil_triangle";
    "SATER_bal_zone" setMarkerColor "ColorOrange";
    "SATER_bal_zone" setMarkerAlpha  0.20;
    "SATER_bal_zone" setMarkerSize  [200, 200];
};

fnc_markerFound = {
    params ["_ax", "_ay", "_distM", "_appr"];
    deleteMarker "SATER_found";
    createMarker ["SATER_found", [_ax, _ay, 0]];
    "SATER_found" setMarkerType  "mil_triangle";
    "SATER_found" setMarkerColor "ColorGreen";
    "SATER_found" setMarkerText  format ["TROUVE %1m %2", round _distM, _appr];
    "SATER_found" setMarkerSize  [0.6, 0.6];
};

fnc_markerNextPoint = {
    params ["_ax", "_ay", "_label"];
    deleteMarker "SATER_next";
    createMarker ["SATER_next", [_ax, _ay, 0]];
    "SATER_next" setMarkerType  "mil_triangle";
    "SATER_next" setMarkerColor "ColorBlue";
    "SATER_next" setMarkerText  _label;
    "SATER_next" setMarkerSize  [0.7, 0.7];
};

// =========================================================================
// Variables globales mission
// =========================================================================

waitUntil { !isNil "BIS_fnc_init" };
sleep 2;

SATER_active     = false;
SATER_found      = false;
SATER_bal_ax     = 0;
SATER_bal_ay     = 0;
SATER_bc         = 0;
SATER_next_ax    = 0;
SATER_next_ay    = 0;
SATER_REL_PENDING = false;  // true quand le joueur appuie sur Relevement

// =========================================================================
// Verification Pythia
// =========================================================================

systemChat "SATER: Initialisation...";

if (isNil "py3_fnc_callExtension") then {
    systemChat "SATER: ERREUR - Pythia non charge !";
    systemChat "SATER: Verifiez -mod=@Pythia;@SaterSim";
} else {
    private _hb = ["sater_code.heartbeat", []] call py3_fnc_callExtension;
    systemChat format ["SATER: Pythia OK - heartbeat = '%1'", _hb];

    if ((_hb isEqualTo "ok") || (_hb isEqualTo "offline")) then {

        // =========================================================
        // GENERATION AUTOMATIQUE DE LA MISSION
        // =========================================================

        private _pos = getPos player;
        private _px  = _pos select 0;
        private _py  = _pos select 1;

        systemChat "SATER: Generation de la mission...";

        private _res = ["sater_code.init_mission",
            [_mapName, _originLat, _originLon, _px, _py]]
            call py3_fnc_callExtension;

        // _res = [bal_ax, bal_ay, sta_ax, sta_ay, scenario_text]
        if (count _res >= 5) then {
            SATER_bal_ax = parseNumber str (_res select 0);
            SATER_bal_ay = parseNumber str (_res select 1);
            private _sta_ax = parseNumber str (_res select 2);
            private _sta_ay = parseNumber str (_res select 3);
            // Verifier que la balise est sur terre (ASL > 0)
            // Si dans l eau, le moteur Python regenerera au prochain heartbeat
            private _bal_asl = getTerrainHeightASL [SATER_bal_ax, SATER_bal_ay];
            if (_bal_asl <= 0) then {
                systemChat format ["SATER: Balise dans eau (ASL=%1) - regeneration...", round _bal_asl];
                // Forcer une nouvelle mission
                private _res2 = ["sater_code.init_mission",
                    ["Altis", 39.0, 22.6, _sta_ax, _sta_ay]] call py3_fnc_callExtension;
                if (count _res2 >= 5) then {
                    SATER_bal_ax = parseNumber str (_res2 select 0);
                    SATER_bal_ay = parseNumber str (_res2 select 1);
                };
                systemChat format ["SATER: Nouvelle balise a [%1,%2] ASL=%3",
                    round SATER_bal_ax, round SATER_bal_ay,
                    round (getTerrainHeightASL [SATER_bal_ax, SATER_bal_ay])];
            };
            private _tx = str (_res select 4);

            SATER_active = true;
            SATER_next_ax = _sta_ax;
            SATER_next_ay = _sta_ay;
            [SATER_bal_ax, SATER_bal_ay] call fnc_createBaliseMarker;

            // Epave d'avion civil sur le site de la balise ELT
            private _wreckDir = random 360;
            private _wreck = "C_Plane_Civil_01_F" createVehicle [SATER_bal_ax, SATER_bal_ay, 0];
            _wreck setDir _wreckDir;
            _wreck setDamage 0.95;  // Tres endommage
            _wreck allowDamage false;


            // Epave d avion civil sur le site de la balise ELT
            private _wreckPos = [SATER_bal_ax, SATER_bal_ay, 0];
            private _wreck = "Land_Wreck_Plane_Civil_F" createVehicle _wreckPos;
            _wreck setDir (random 360);
            // Fumee legere pour visibilite
            private _smoke = "SlightlyDamagedVehicle" createVehicle _wreckPos;

            // Le marqueur DEPART sera cree apres le calcul de _spawnPos
            // Joueur place par l editeur (mission.sqm) - pas de teleportation

            // Vehicule et heli definis dans mission.sqm
            private _spx = _spawnPos select 0; private _spy = _spawnPos select 1;




            // Joueur configure dans l editeur (B_soldier_UAV_F)
            // Equipement conserve - ajouter seulement ce qui manque
            if (!("ItemGPS" in items player)) then { player addItem "ItemGPS"; };
            player assignItem "ItemGPS";
            if (!("ItemMap" in items player)) then { player addItem "ItemMap"; };
            player assignItem "ItemMap";
            if (!("ItemCompass" in items player)) then { player addItem "ItemCompass"; };
            player assignItem "ItemCompass";
            if (!("ItemRadio" in items player)) then { player addItem "ItemRadio"; };
            player assignItem "ItemRadio";
            // Assigner le terminal UAV s il est dans l inventaire
            if ("B_UavTerminal" in items player) then {
                player assignItem "B_UavTerminal";
                systemChat "SATER: Terminal UAV assigne";
            } else {
                // L ajouter si absent
                player addItem "B_UavTerminal";
                player assignItem "B_UavTerminal";
                systemChat "SATER: Terminal UAV ajoute et assigne";
            };
            // Epave d avion a la position de la balise
            private _wreckPos = [SATER_bal_ax, SATER_bal_ay, 0];
            private _wreck = "Land_Wreck_Plane_Civil_F" createVehicle _wreckPos;
            _wreck setDir (random 360);
            // Marqueur epave
            deleteMarker "SATER_epave";
            // (pas de marqueur visible - l operateur doit la trouver)
            // Drone de l editeur - connecter via BIS
            {
                if (typeOf _x == "B_UAV_01_F") then {
                    [_x] join (group player);
                    [_x, player] call BIS_fnc_UAVconnect;
                    systemChat "SATER: Drone Darter connecte - Carte->UAV->Controler";
                };
            } forEach vehicles;

            // Messages mission
            ["=== NOUVELLE MISSION SATER ===", [1.0, 1.0, 0.0, 1.0]] call fnc_saterMsg;
            systemChat "SATER: === NOUVELLE MISSION ===";
            systemChat _tx;
            systemChat "SATER: Rejoindre DEPART > Regard=Yagi > R=relevement";
            // Message vocal debut mission
            ["pco_start.wav"] call fnc_pcoSound;
            openMap [true, false];
        } else {
            systemChat format ["SATER: Erreur : %1", _res];
        };

        // =========================================================
        // Thread heartbeat
        // =========================================================
        [_heartbeatS] spawn {
            params ["_interval"];
            while {true} do {
                ["sater_code.heartbeat", []] call py3_fnc_callExtension;
                sleep _interval;
            };
        };

        // =========================================================
        // Charger les marqueurs de relevements
        // =========================================================
        [] execVM "sater_bearings.sqf";

        // =========================================================
        // Boucle HUD principale
        // =========================================================
        [_hudRefresh, _foundRadius] spawn {
            params ["_refresh", "_fRadius"];
            while {true} do {
                // Detection mode drone UAV via cameraOn
                // cameraOn retourne l objet dont on voit la camera
                // Si c est le drone -> joueur aux commandes du terminal UAV
                private _activeDrone = objNull;
                {
                    if (typeOf _x == "B_UAV_01_F") then { _activeDrone = _x; };
                } forEach vehicles;

                private _cam = cameraOn;
                private _droneMode = (!isNull _activeDrone) &&
                    (_cam == _activeDrone || vehicle _cam == _activeDrone);

                // Position et cap selon mode
                private _pos = if (_droneMode) then {getPos _activeDrone} else {getPos player};
                private _pax = _pos select 0;
                private _pay = _pos select 1;
                private _yaw = if (_droneMode) then {
                    getDir _activeDrone
                } else {
                    getDir player
                };

                // Detection balise
                private _found = false;
                private _distBal = 9999.0;
                if (SATER_active && !SATER_found && (abs SATER_bal_ax > 0.01)) then {
                    _distBal = sqrt(
                        ((_pax - SATER_bal_ax)^2) + ((_pay - SATER_bal_ay)^2)
                    );
                    if (_distBal <= _fRadius) then { _found = true; };
                };

                // Appel tick
                private _r = ["sater_code.tick",
                    [_pax, _pay, _yaw, _found, _pax, _pay]]
                    call py3_fnc_callExtension;

                if ((typeName _r == "ARRAY") && (count _r >= 5)) then {
                    private _rssi    = _r select 0;
                    private _bearing = _r select 1;
                    private _distM   = _r select 2;
                    private _sLevel  = _r select 3;

                    [_rssi, _bearing, _distM, _sLevel, "ok", SATER_bc]
                        call fnc_drawHUD;

                    // Relevement en attente
                    if (SATER_REL_PENDING && SATER_active) then {
                        SATER_REL_PENDING = false;
                        private _rb = ["sater_code.add_bearing",
                            [_pax, _pay, _yaw]] call py3_fnc_callExtension;
                        // _rb = [next_ax, next_ay, msg, bc]
                        if ((typeName _rb == "ARRAY") && (count _rb >= 4)) then {
                            SATER_bc      = _rb select 3;
                            SATER_next_ax = _rb select 0;
                            SATER_next_ay = _rb select 1;
                            private _msg  = _rb select 2;
                            [SATER_next_ax, SATER_next_ay,
                             format ["R%1", SATER_bc]] call fnc_markerNextPoint;
                            // Choisir le fichier audio selon le numero de relevement
                            private _pcoFile = switch (true) do {
                                case (SATER_bc == 1): {"pco_r1.wav"};
                                case (SATER_bc == 2): {"pco_r2.wav"};
                                case (SATER_bc == 3): {"pco_r3.wav"};
                                case (SATER_bc >= 4): {"pco_r4.wav"};
                                default {"pco_r1.wav"};
                            };
                            [_pcoFile] call fnc_pcoSound;
                            [format ["PCO >> %1", _msg], [0.5, 1.0, 1.0, 1.0]] call fnc_saterMsg;
                            systemChat format ["PCO >> %1", _msg];
                            player sideChat format ["R%1 - Az: %2 deg",
                                SATER_bc, round _yaw];
                        };
                    };

                    // Son ELT quand signal fort (S-metre vert, RSSI > 0.6)
                    if (_rssi > 0.6 && SATER_active && !SATER_found) then {
                        private _vol = (_rssi - 0.6) * 2.5;
                        if ((time - (uiNamespace getVariable ["SATER_ELT_LAST", 0])) > 3.5) then {
                            uiNamespace setVariable ["SATER_ELT_LAST", time];
                            // Son ELT depuis la position de la balise
                            playSound3D ["elt.wav", player, false,
                                [SATER_bal_ax, SATER_bal_ay, 0], _vol, 1.0, 2000];
                            // Message vocal PCO signal fort (une seule fois)
                            if (!(uiNamespace getVariable ["SATER_SIGNAL_FORT", false])) then {
                                uiNamespace setVariable ["SATER_SIGNAL_FORT", true];
                                ["pco_signal_fort.wav"] call fnc_pcoSound;
                                ["Signal fort ! Maintenez le cap.", [0.0, 1.0, 0.3, 1.0]] call fnc_saterMsg;
                            };
                        };
                    } else {
                        // Reinitialiser quand signal redevient faible
                        if (_rssi < 0.4) then {
                            uiNamespace setVariable ["SATER_SIGNAL_FORT", false];
                        };
                    };

                    // Balise trouvee
                    if (_found && !SATER_found) then {
                        SATER_found  = true;
                        SATER_active = false;
                        private _fr  = ["sater_code.declare_found",
                            [_pax, _pay]] call py3_fnc_callExtension;
                        // _fr = [dist_m, appr, bal_ax, bal_ay]
                        if ((typeName _fr == "ARRAY") && (count _fr >= 4)) then {
                            private _dm   = _fr select 0;
                            private _appr = _fr select 1;
                            private _bax  = _fr select 2;
                            private _bay  = _fr select 3;
                            [_bax, _bay, _dm, _appr] call fnc_markerFound;
                            ["pco_found.wav"] call fnc_pcoSound;
                            [format ["BALISE LOCALISEE ! %1 m - %2", round _dm, _appr],
                             [0.0, 1.0, 0.3, 1.0]] call fnc_saterMsg;
                            player sideChat format [
                                "EQUIPIER >> PCO : BALISE LOCALISEE ! %1 m. %2.",
                                round _dm, _appr
                            ];
                            systemChat format [
                                "SATER: BALISE TROUVEE a %.0f m - Appreciation: %1",
                                _dm, _appr
                            ];
                        };
                    };
                };
                sleep _refresh;
            };
        };

        // =========================================================
        // Action clavier : Maj+R = RELEVEMENT
        // =========================================================
        [] spawn {
            while {true} do {
                // Detecter appui sur "R" (0x52) avec Shift
                if (SATER_active && !SATER_found) then {
                    if ((inputAction "ReloadMagazine") > 0) then {
                        if (not SATER_REL_PENDING) then {
                            SATER_REL_PENDING = true;
                            hint format ["Relevement R%1 enregistre - Az: %2 deg",
                                SATER_bc + 1, round (getDir player)];
                        };
                        sleep 0.5;  // anti-rebond
                    };
                };
                sleep 0.1;
            };
        };

    } else {
        systemChat format ["SATER: Erreur Pythia - heartbeat = '%1'", _hb];
    };
};

systemChat "SATER_LOGIC.SQF v3 - Mission autonome prete.";
