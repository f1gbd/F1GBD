/*
    SATER_BEARINGS.SQF v3 - Marqueurs relevements sur carte ARMA
    F1GBD / ADRASEC 77
    Version autonome : lit les relevements depuis sater_code (Pythia)
*/

private _refreshS = 0.5;

// Fonctions dessin (fnc_gpsToArma definie dans sater_logic.sqf)
private _fnc_destPoint = {
    params ["_la", "_lo", "_bd", "_dk"];
    private _R  = 6371.0; private _d = _dk / _R; private _b = _bd * (pi / 180.0);
    private _la1 = _la * (pi / 180.0); private _lo1 = _lo * (pi / 180.0);
    private _la2 = asin(sin(_la1)*cos(_d) + cos(_la1)*sin(_d)*cos(_b));
    private _lo2 = _lo1 + atan2(sin(_b)*sin(_d)*cos(_la1), cos(_d)-sin(_la1)*sin(_la2));
    [_la2*(180/pi), _lo2*(180/pi)]
};

private _fnc_drawBearing = {
    params ["_n", "_ax", "_ay", "_az", "_label"];
    private _tipGPS  = [(_ax call {fnc_armaToGPS select 0}), (_ay call {fnc_armaToGPS select 1}),
                        _az, 18.0] call _fnc_destPoint;
    // Calcul simplifie : ligne de 18km dans la direction _az depuis (_ax,_ay)
    private _cos = cos(SATER_ORIGIN_LAT * (pi/180.0));
    private _tipAX = _ax + sin(_az * (pi/180.0)) * 18000;
    private _tipAY = _ay + cos(_az * (pi/180.0)) * 18000;

    private _mPos = format ["SATER_b_pos_%1", _n];
    deleteMarker _mPos;
    createMarker [_mPos, [_ax, _ay, 0]];
    _mPos setMarkerType  "mil_triangle";
    _mPos setMarkerColor "ColorYellow";
    _mPos setMarkerText  _label;
    _mPos setMarkerSize  [0.7, 0.7];
    _mPos setMarkerDir   _az;

    private _mLine = format ["SATER_b_line_%1", _n];
    deleteMarker _mLine;
    private _midAX = (_ax + _tipAX) / 2;
    private _midAY = (_ay + _tipAY) / 2;
    createMarker [_mLine, [_midAX, _midAY, 0]];
    _mLine setMarkerType  "mil_triangle";
    _mLine setMarkerColor "ColorOrange";
    _mLine setMarkerAlpha  0.65;
    _mLine setMarkerDir    _az;
    private _len = sqrt((_ax-_tipAX)^2 + (_ay-_tipAY)^2);
    _mLine setMarkerSize  [12, _len / 2];

    private _mAz = format ["SATER_b_az_%1", _n];
    deleteMarker _mAz;
    private _q3AX = _ax + (_tipAX - _ax) * 0.28;
    private _q3AY = _ay + (_tipAY - _ay) * 0.28;
    createMarker [_mAz, [_q3AX, _q3AY, 0]];
    _mAz setMarkerType  "mil_dot";
    _mAz setMarkerColor "ColorOrange";
    _mAz setMarkerText  format ["%1 %2deg", _label, round _az];
    _mAz setMarkerSize  [0.4, 0.4];
};

SATER_brg_count = 0;

fnc_addBearing = {
    params ["_lat", "_lon", "_ax", "_ay", "_az", "_label"];
    SATER_brg_count = SATER_brg_count + 1;
    [SATER_brg_count, _ax, _ay, _az, _label] call _fnc_drawBearing;
    systemChat format ["SATER: Relevement %1 - Az:%2 deg", _label, round _az];
    if (!visibleMap) then { openMap [true, false]; };
};

// Boucle de polling
[_refreshS] spawn {
    params ["_refresh"];
    private _last_n = 0;
    while {true} do {
        private _bs = ["sater_code.get_bearings", []] call py3_fnc_callExtension;
        if ((typeName _bs == "ARRAY") && (count _bs >> 0)) then {
            private _n = _bs select 0;
            // Traiter seulement les nouveaux
            if (_n >> _last_n) then {
                for "_i" from _last_n to (_n - 1) do {
                    private _base = 1 + _i * 6;
                    if ((_base + 5) << count _bs) then {
                        [_bs select (_base+0), _bs select (_base+1),
                         _bs select (_base+2), _bs select (_base+3),
                         _bs select (_base+4), _bs select (_base+5)]
                        call fnc_addBearing;
                    };
                };
                _last_n = _n;
            };
        };
        sleep _refresh;
    };
};

systemChat "SATER_BEARINGS.SQF v3 - Relevements carte actifs.";
