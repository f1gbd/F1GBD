// init.sqf - SATER Mission Autonome ARMA III
if (hasInterface) then {
    [] execVM "briefing.sqf";
    [] execVM "sater_logic.sqf";
};
