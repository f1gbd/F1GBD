// briefing.sqf - Charge par init.sqf pour afficher le briefing dans la carte
// Accessible via touche M -> onglet Notes/Briefing

player createDiaryRecord ["Diary", [
    "MISSION SATER - Exercice ELT 121.5 MHz",
    "Vous etes operateur ADRASEC en charge de la recherche d une balise ELT declenchee.<br/><br/>
    <font color='#ffcc00'>MATERIEL :</font><br/>
    Recepteur ELT 121.5 MHz (HUD en bas a gauche)<br/>
    Antenne Yagi directionnelle (direction du regard)<br/>
    Carte avec marqueurs de relevements<br/><br/>
    <font color='#ffcc00'>PROCEDURE :</font><br/>
    1. Rejoindre le point DEPART marque sur la carte<br/>
    2. Orienter le regard vers le signal maximum (barre S-metre)<br/>
    3. Appuyer sur <font color='#aaddff'>[R]</font> pour enregistrer un relevement<br/>
    4. Se deplacer vers le prochain point indique<br/>
    5. Repeter jusqu a localisation precise<br/>
    6. Approcher physiquement la balise (detection a 15m)<br/><br/>
    <font color='#ffcc00'>HUD :</font><br/>
    - Ligne haute : CAP vers la balise (en degres)<br/>
    - Ligne milieu : S-metre + barre signal RSSI<br/>
    - Ligne basse : Frequence + Relevement N + Distance<br/><br/>
    <font color='#ff6600'>EXERCICE EXERCICE EXERCICE</font>"
]];

player createDiaryRecord ["Diary", [
    "Lexique SATER",
    "<font color='#ffcc00'>ELT</font> : Emergency Locator Transmitter - Balise de detresse aeronautique<br/>
    <font color='#ffcc00'>RSSI</font> : Received Signal Strength Indicator - Force du signal recu<br/>
    <font color='#ffcc00'>S-metre</font> : Echelle 0-9 de force du signal radio<br/>
    <font color='#ffcc00'>ADRASEC</font> : Ass. Departementale Radio Amateur de Securite Civile<br/>
    <font color='#ffcc00'>Goniometrie</font> : Determination de la direction d une source radio<br/>
    <font color='#ffcc00'>Relevement</font> : Mesure d azimut vers la source depuis un point connu<br/>
    <font color='#ffcc00'>121.5 MHz</font> : Frequence internationale de detresse aeronautique"
]];
