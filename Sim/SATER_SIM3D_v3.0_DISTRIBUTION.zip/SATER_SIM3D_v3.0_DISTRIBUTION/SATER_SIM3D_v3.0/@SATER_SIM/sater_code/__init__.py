# sater_code/__init__.py - Moteur SATER complet pour Pythia/ARMA III
# F1GBD / ADRASEC 77
# Version autonome : pas de SATER_Sim3D.py, pas de GUI
# Tout passe par le HUD ARMA III et la carte ARMA
# La mission est generee automatiquement au restart de la mission ARMA

import socket, json, threading, time, math, random, os

# - Ports UDP (conserves pour compatibilite arma_bridge si besoin) -
_HOST    = "127.0.0.1"
_PORT_R  = 5020
_PORT_S  = 5021

# - Verrou global -
_lock = threading.Lock()

# - Sockets -
_sr    = None
_ss    = None
_ready = False

# - Fichier de sauvegarde mission -
_MISSION_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "mission.json"
)

# - Etat de la mission -
_mission = {
    "active"     : False,
    "sc"         : None,   # scenario : {cla,clo,tx,sla,slo}
    "op_lat"     : 0.0,    # position operateur GPS
    "op_lon"     : 0.0,
    "op_ax"      : 0.0,    # position operateur ARMA (metres)
    "op_ay"      : 0.0,
    "bal_ax"     : 0.0,    # position balise ARMA
    "bal_ay"     : 0.0,
    "yagi_az"    : 0.0,    # azimut Yagi (= direction regard joueur)
    "rssi"       : 0.0,
    "bearing"    : 0.0,
    "dist_m"     : 9999.0,
    "s_level"    : 0,
    "bc"         : 0,      # nombre de relevements
    "bearings"   : [],     # liste des relevements
    "found"      : False,
    "origin_lat" : 0.0,    # origine GPS de la map ARMA
    "origin_lon" : 0.0,
    "map_name"   : "Altis",
}

# - Origines GPS des maps ARMA connues -
_MAP_ORIGINS = {
    "Altis"    : (39.0,  22.6),
    "Stratis"  : (39.20, 20.60),
    "Tanoa"    : (-17.5, 178.0),
    "Livonia"  : (51.5,  23.0),
    "Malden"   : (45.75,  3.0),
    "VR"       : (0.0,    0.0),
}

# - Zones de crash adaptees aux maps ARMA -
# Pour Altis : zones dans les coordonnees GPS reelles de la carte
_ALTIS_ZONES = [
    {"la": 39.1392, "lo": 22.7676},
    {"la": 39.1437, "lo": 22.7792},
    {"la": 39.1527, "lo": 22.7618},
    {"la": 39.1572, "lo": 22.7734},
    {"la": 39.1662, "lo": 22.7676},
    {"la": 39.1617, "lo": 22.7792},
    {"la": 39.1707, "lo": 22.7618},
    {"la": 39.1752, "lo": 22.7734},
    {"la": 39.1482, "lo": 22.7676},
    {"la": 39.1347, "lo": 22.7792},
]

# -
# Fonctions geodesiques (portees depuis SATER_Sim3D.py)
# -

def _hav(a1, o1, a2, o2):
    R = 6371.0
    dl = math.radians(a2 - a1)
    dn = math.radians(o2 - o1)
    a  = math.sin(dl/2)**2 + math.cos(math.radians(a1)) * math.cos(math.radians(a2)) * math.sin(dn/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def _brg(a1, o1, a2, o2):
    dn  = math.radians(o2 - o1)
    la1 = math.radians(a1)
    la2 = math.radians(a2)
    return (math.degrees(math.atan2(
        math.sin(dn) * math.cos(la2),
        math.cos(la1) * math.sin(la2) - math.sin(la1) * math.cos(la2) * math.cos(dn)
    )) + 360) % 360

def _destp(la, lo, bd, dk):
    R = 6371.0
    d  = dk / R
    b  = math.radians(bd)
    la1 = math.radians(la)
    lo1 = math.radians(lo)
    la2 = math.asin(math.sin(la1) * math.cos(d) + math.cos(la1) * math.sin(d) * math.cos(b))
    lo2 = lo1 + math.atan2(math.sin(b) * math.sin(d) * math.cos(la1),
                            math.cos(d) - math.sin(la1) * math.sin(la2))
    return math.degrees(la2), math.degrees(lo2)

def _gps_to_arma(origin_lat, origin_lon, lat, lon):
    cos_lat = math.cos(math.radians(origin_lat))
    ax = (lon - origin_lon) * 111320.0 * cos_lat
    ay = (lat - origin_lat) * 111320.0
    return ax, ay

def _arma_to_gps(origin_lat, origin_lon, ax, ay):
    cos_lat = math.cos(math.radians(origin_lat))
    lat = origin_lat + ay / 111320.0
    lon = origin_lon + ax / (111320.0 * cos_lat)
    return lat, lon

def _dms(d, is_lat=True):
    dd  = abs(d)
    deg = int(dd)
    mf  = (dd - deg) * 60
    h   = ("N" if d >= 0 else "S") if is_lat else ("E" if d >= 0 else "W")
    return "%d%02.3f%s" % (deg, mf, h)

def _dms_str(la, lo):
    return "%s %s" % (_dms(la, True), _dms(lo, False))

# -
# Calcul RSSI (porte depuis SATER_Sim3D._compute_rssi)
# -

def _compute_rssi(op_lat, op_lon, bal_lat, bal_lon, yagi_az):
    tb   = _brg(op_lat, op_lon, bal_lat, bal_lon)
    unc  = random.uniform(-3, 3)
    diff = ((yagi_az - (tb + unc)) + 180) % 360 - 180
    ad   = abs(diff)
    if   ad <= 90:  gain = math.cos(math.radians(ad)) ** 3
    elif ad <= 150: gain = 0.02
    else:
        bd = abs(180 - ad)
        gain = 0.10 * math.cos(math.radians(bd * 3)) ** 2 if bd < 30 else 0.02
    dist = _hav(op_lat, op_lon, bal_lat, bal_lon)
    return max(0.0, gain * max(0.05, 1.0 / (1 + dist * 0.08)))

# -
# Generation de scenario (porte depuis SATER_Sim3D.gen_sc)
# Adapte pour utiliser les coordonnees de la map ARMA
# -

_AC = ["Robin ATL","Robin DR400","Cessna 172","Cessna 152","Piper PA-28",
       "Jodel D112","Rallye MS893","TB-10 Tobago","DA40 Diamond Star","SR22 Cirrus"]
_PB = ["des problemes moteur","une perte de puissance moteur","un feu moteur",
       "des vibrations anormales","une panne electrique","une perte de pression huile",
       "un givrage carburateur","une fumee dans le cockpit"]
_WP = ["NOVEMBER","SIERRA","TANGO","BRAVO","ALPHA","DELTA","FOXTROT",
       "GOLF","HOTEL","INDIA","JULIET","KILO","LIMA","MIKE","PAPA",
       "QUEBEC","ROMEO","UNIFORM","VICTOR"]
_NATO = ["","UN","DEUX","TROIS","QUATRE","CINQ","SIX","SEPT","HUIT","NEUF","DIX",
         "ONZE","DOUZE","TREIZE","QUATORZE","QUINZE"]

def _gen_sc(origin_lat, origin_lon, map_name="Altis"):
    """Genere un scenario SATER - balise aleatoire autour du point de depart fixe."""

    # Point de depart fixe depuis mission.sqm
    STA_AX = 15180.0  # position ARMA reelle joueur (mission.sqm)
    STA_AY = 17336.7

    # Generer la balise a 3-10 km du depart dans une direction aleatoire
    angle  = random.uniform(0, 360)
    dist_m = random.uniform(3000, 9000)  # metres ARMA
    bax = STA_AX + dist_m * math.sin(math.radians(angle))
    bay = STA_AY + dist_m * math.cos(math.radians(angle))

    # Clamping zone terrestre Altis centre
    bax = max(8000, min(24000, bax))
    bay = max(8000, min(24000, bay))

    # Convertir en GPS pour le texte du scenario
    cos_lat = math.cos(math.radians(origin_lat))
    cla = origin_lat + bay / 111320.0
    clo = origin_lon + bax / (111320.0 * cos_lat)

    # Point de depart fixe en GPS
    sla = origin_lat + STA_AY / 111320.0
    slo = origin_lon + STA_AX / (111320.0 * cos_lat)

    # Texte scenario
    ac  = random.choice(_AC)
    pb  = random.choice(_PB)
    w1  = random.choice(_WP)
    w2  = random.choice([w for w in _WP if w != w1])
    h   = random.randint(6, 18)
    m   = random.randint(0, 59)
    t1  = "%02dh%02d" % (h, m)
    tp  = "%04d" % random.randint(1000, 7777)
    bal_dms = _dms_str(cla, clo)
    tx  = ("SATER - EXERCICE ALTIS : BALISE ELT LOCALISEE APROXIMATIVEMENT "
           "EN SECTEUR %s. AERONEF %s (CODE %s) SIGNALE %s. "
           "HEURE DECLENCHEMENT ESTIMEE %s. "
           "POINT WAYPOINT %s PUIS %s." % (
               bal_dms, ac.upper(), tp, pb.upper(), t1, w1, w2))

    return {
        "cla" : cla,  "clo" : clo,
        "sla" : sla,  "slo" : slo,
        "bal_ax": int(round(bax)), "bal_ay": int(round(bay)),
        "sta_ax": int(round(STA_AX)), "sta_ay": int(round(STA_AY)),
        "tx"  : tx, "ac" : ac, "tp" : tp,
    }


def _pco_nxt(sc, la, lo, bc, origin_lat, origin_lon):
    d  = _hav(la, lo, sc["cla"], sc["clo"])
    if d < 1.5:
        return {"t":"close","la":la,"lo":lo,
                "m":"Vous etes tres proche. Recherche fine. Signalez la balise."}
    bt = _brg(la, lo, sc["cla"], sc["clo"])
    if   bc <= 1: nb = (bt + random.uniform(70, 100)) % 360;  nd = d * random.uniform(0.5, 0.7)
    elif bc <= 3: nb = (bt + random.uniform(40, 70) * (1 if random.random() > .5 else -1)) % 360; nd = d * random.uniform(0.3, 0.5)
    else:         nb = (bt + random.uniform(-30, 30)) % 360;  nd = d * random.uniform(0.1, 0.3)
    nd  = max(0.5, min(nd, 15))
    nl, nlo = _destp(sc["cla"], sc["clo"], nb, nd)

    # Convertir en ARMA pour que SQF puisse deplacer le joueur
    nax, nay = _gps_to_arma(origin_lat, origin_lon, nl, nlo)
    ps  = _dms_str(nl, nlo)
    nxt = bc + 1
    pname = "ROMEO %s" % (_NATO[nxt] if nxt < len(_NATO) else str(nxt))
    rshort = "R%d" % nxt
    if bc <= 1:
        ms = "Bien recu. Deplacez-vous au point %s, %s, position %s, et donnez un nouveau relevement." % (pname, rshort, ps)
    elif bc <= 3:
        ms = "Triangulation en cours. Allez au point %s, %s, position %s." % (pname, rshort, ps)
    else:
        ms = "Relevements convergent. Approchez du point %s, %s, position %s." % (pname, rshort, ps)
    return {"t":"move","la":nl,"lo":nlo,"ax":nax,"ay":nay,"m":ms,"label":rshort}

# -
# Sauvegarde / chargement mission.json
# -

def _save_mission():
    try:
        with _lock:
            data = {
                "map_name"   : _mission["map_name"],
                "origin_lat" : _mission["origin_lat"],
                "origin_lon" : _mission["origin_lon"],
                "sc"         : _mission["sc"],
                "op_lat"     : _mission["op_lat"],
                "op_lon"     : _mission["op_lon"],
                "bc"         : _mission["bc"],
                "bearings"   : _mission["bearings"],
                "found"      : _mission["found"],
                "active"     : _mission["active"],
            }
        with open(_MISSION_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def _load_mission():
    try:
        if os.path.exists(_MISSION_FILE):
            with open(_MISSION_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            with _lock:
                for k in ("map_name","origin_lat","origin_lon","sc","op_lat",
                          "op_lon","bc","bearings","found","active"):
                    if k in data:
                        _mission[k] = data[k]
    except Exception:
        pass

# -
# Sockets UDP (conserves pour compatibilite arma_bridge)
# -

def _setup():
    global _sr, _ss, _ready
    if _ready:
        return
    try:
        _sr = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        _sr.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        _sr.settimeout(0.05)
        _sr.bind((_HOST, _PORT_R))
        _ss = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        threading.Thread(target=_recv_loop, daemon=True).start()
        _ready = True
    except Exception:
        pass

def _recv_loop():
    while True:
        try:
            data, _ = _sr.recvfrom(4096)
            _apply(json.loads(data.decode()))
        except socket.timeout:
            pass
        except Exception:
            time.sleep(0.1)

def _apply(p):
    cmd = p.get("cmd", "")
    if cmd == "shutdown":
        with _lock:
            _mission["active"] = False

def _send(p):
    try:
        _ss.sendto(json.dumps(p).encode(), (_HOST, _PORT_S))
    except Exception:
        pass

# -
# Fonctions publiques Pythia (appelees depuis SQF)
# -

def heartbeat():
    """Appelee toutes les secondes par SQF. Retourne 'ok'."""
    _setup()
    return "ok"


def init_mission(map_name, origin_lat, origin_lon, player_ax, player_ay):
    """
    Appelee au debut de la mission SQF (init.sqf ou restart).
    Genere un nouveau scenario SATER et sauvegarde dans mission.json.

    Parametres :
        map_name    : nom de la map ARMA (ex: "Altis")
        origin_lat  : latitude GPS de l'origine de la map
        origin_lon  : longitude GPS de l'origine de la map
        player_ax   : position X du joueur en metres (ARMA)
        player_ay   : position Y du joueur en metres (ARMA)

    Retourne [bal_ax, bal_ay, sta_ax, sta_ay, scenario_text]
        bal_ax/ay : position ARMA de la balise (pour placer le marqueur)
        sta_ax/ay : position de depart de l'operateur
        scenario_text : texte du message PCO initial
    """
    _setup()

    olat = float(origin_lat)
    olon = float(origin_lon)
    pax  = float(player_ax)
    pay  = float(player_ay)
    mname = str(map_name)

    # Convertir position joueur en GPS
    plat, plon = _arma_to_gps(olat, olon, pax, pay)

    # Generer scenario
    sc = _gen_sc(olat, olon, mname)

    with _lock:
        _mission["map_name"]    = mname
        _mission["origin_lat"]  = olat
        _mission["origin_lon"]  = olon
        _mission["sc"]          = sc
        _mission["op_lat"]      = sc["sla"]
        _mission["op_lon"]      = sc["slo"]
        _mission["op_ax"]       = sc["sta_ax"]
        _mission["op_ay"]       = sc["sta_ay"]
        _mission["bal_ax"]      = sc["bal_ax"]
        _mission["bal_ay"]      = sc["bal_ay"]
        _mission["yagi_az"]     = 0.0
        _mission["rssi"]        = 0.0
        _mission["bc"]          = 0
        _mission["bearings"]    = []
        _mission["found"]       = False
        _mission["active"]      = True

    _save_mission()

    return [
        int(round(sc["bal_ax"])),
        int(round(sc["bal_ay"])),
        int(round(sc["sta_ax"])),
        int(round(sc["sta_ay"])),
        str(sc["tx"]),
    ]


def tick(player_ax, player_ay, yagi_az, found=False, near_ax=0.0, near_ay=0.0):
    """
    Appelee toutes les 250ms par SQF.
    Calcule RSSI, bearing, distance depuis la position ARMA du joueur.

    Parametres :
        player_ax/ay : position ARMA du joueur (metres)
        yagi_az      : azimut Yagi = getDir player (0-360)
        found        : true si joueur proche de la balise (<15m)
        near_ax/ay   : position ARMA du joueur quand found=true

    Retourne [rssi, bearing_deg, dist_m, s_level, status_str]
    """
    _setup()

    with _lock:
        if not _mission["active"] or _mission["sc"] is None:
            return [0.0, 0.0, 9999.0, 0, "waiting"]
        sc      = _mission["sc"]
        olat    = _mission["origin_lat"]
        olon    = _mission["origin_lon"]
        bal_ax  = _mission["bal_ax"]
        bal_ay  = _mission["bal_ay"]

    pax = float(player_ax)
    pay = float(player_ay)
    yaw = float(yagi_az)

    # Convertir positions ARMA en GPS
    plat, plon = _arma_to_gps(olat, olon, pax, pay)
    blat, blon = _arma_to_gps(olat, olon, bal_ax, bal_ay)

    # Calculs
    dist_km = _hav(plat, plon, blat, blon)
    bearing = _brg(plat, plon, blat, blon)
    rssi    = _compute_rssi(plat, plon, blat, blon, yaw)
    s_level = min(9, max(0, int(rssi * 9.5)))

    with _lock:
        _mission["op_lat"]   = plat
        _mission["op_lon"]   = plon
        _mission["op_ax"]    = pax
        _mission["op_ay"]    = pay
        _mission["yagi_az"]  = yaw
        _mission["rssi"]     = rssi
        _mission["bearing"]  = bearing
        _mission["dist_m"]   = dist_km * 1000

    status = "found" if found else "ok"
    return [
        round(rssi,    4),
        round(bearing, 1),
        round(dist_km * 1000, 1),
        s_level,
        status,
    ]


def add_bearing(player_ax, player_ay, yagi_az):
    """
    Enregistre un relevement depuis la position actuelle du joueur.
    Appelee quand le joueur appuie sur le bouton RELEVEMENT dans ARMA.

    Retourne [next_ax, next_ay, message_pco, bearing_count]
        next_ax/ay : position du prochain point de relevement (ARMA metres)
        message_pco : message a afficher comme chat radio
        bearing_count : nombre de relevements effectues
    """
    _setup()

    with _lock:
        if not _mission["active"] or _mission["sc"] is None:
            return [0.0, 0.0, "Mission inactive.", 0]
        sc   = _mission["sc"]
        olat = _mission["origin_lat"]
        olon = _mission["origin_lon"]
        bc   = _mission["bc"]
        yaw  = float(yagi_az)

    pax = float(player_ax)
    pay = float(player_ay)
    plat, plon = _arma_to_gps(olat, olon, pax, pay)

    # Enregistrer le relevement
    rname = "R%d" % (bc + 1)
    brg_val = float(yagi_az)
    b_entry = {
        "lat":    plat,
        "lon":    plon,
        "ax":     pax,
        "ay":     pay,
        "azimut": brg_val,
        "label":  rname,
    }

    # Calculer le prochain point
    result = _pco_nxt(sc, plat, plon, bc + 1, olat, olon)

    with _lock:
        _mission["bc"] += 1
        _mission["bearings"].append(b_entry)
        if result["t"] == "move":
            _mission["op_lat"] = result["la"]
            _mission["op_lon"] = result["lo"]
            _mission["op_ax"]  = result["ax"]
            _mission["op_ay"]  = result["ay"]

    _save_mission()

    if result["t"] == "close":
        return [int(round(pax)), int(round(pay)), result["m"], _mission["bc"]]
    else:
        return [
            int(round(result["ax"])),
            int(round(result["ay"])),
            str(result["m"]),
            _mission["bc"],
        ]


def get_bearings():
    """
    Retourne tous les relevements enregistres.
    Format : [n, lat1, lon1, ax1, ay1, az1, label1, ...]
    """
    _setup()
    with _lock:
        bs = list(_mission["bearings"])
    result = [len(bs)]
    for b in bs:
        result.extend([
            float(b.get("lat",    0.0)),
            float(b.get("lon",    0.0)),
            float(b.get("ax",     0.0)),
            float(b.get("ay",     0.0)),
            float(b.get("azimut", 0.0)),
            str(  b.get("label",  "R-")),
        ])
    return result


def declare_found(player_ax, player_ay):
    """
    Appelee quand le joueur trouve la balise (<15m).
    Calcule la precision et retourne le bilan.

    Retourne [dist_reelle_m, appreciation_str, bal_ax, bal_ay]
    """
    _setup()

    with _lock:
        if not _mission["active"] or _mission["sc"] is None:
            return [0.0, "Mission inactive.", 0.0, 0.0]
        sc   = _mission["sc"]
        olat = _mission["origin_lat"]
        olon = _mission["origin_lon"]
        bal_ax = _mission["bal_ax"]
        bal_ay = _mission["bal_ay"]
        _mission["found"] = True
        _mission["active"] = False

    pax = float(player_ax)
    pay = float(player_ay)
    dist_m = math.sqrt((pax - bal_ax)**2 + (pay - bal_ay)**2)

    if   dist_m < 5:   appr = "EXCELLENT"
    elif dist_m < 15:  appr = "TRES BON"
    elif dist_m < 50:  appr = "BON"
    elif dist_m < 150: appr = "PASSABLE"
    else:              appr = "HORS ZONE"

    _save_mission()

    return [
        int(round(dist_m)),
        appr,
        int(round(bal_ax)),
        int(round(bal_ay)),
    ]


def get_mission_status():
    """
    Retourne l'etat complet de la mission.
    [active, bc, dist_m, rssi, bearing, bal_ax, bal_ay, op_ax, op_ay, found]
    """
    _setup()
    with _lock:
        m = _mission
        return [
            1 if m["active"] else 0,
            int(m["bc"]),
            int(round(m["dist_m"])),
            round(m["rssi"],    4),
            round(m["bearing"], 1),
            int(round(m["bal_ax"])),
            int(round(m["bal_ay"])),
            int(round(m["op_ax"])),
            int(round(m["op_ay"])),
            1 if m["found"] else 0,
        ]
