license = "APL-SA";
picture = "logo_SATER.paa";
overviewPicture = "logo_SATER.paa";
overviewText = "SATER SIM3D - Simulateur de recherche balise ELT 121.5 MHz pour la formation ADRASEC/FNRASEC. Integre avec Pythia Python Extension.";
overviewFootnote = "v3.0 - F1GBD / ADRASEC 77";
