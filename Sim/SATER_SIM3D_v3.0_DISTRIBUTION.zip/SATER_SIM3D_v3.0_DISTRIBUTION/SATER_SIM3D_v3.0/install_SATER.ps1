# ============================================================
# SATER SIM3D - Script d'installation automatique
# F1GBD / ADRASEC 77
# Usage : powershell -ExecutionPolicy Bypass -File install_SATER.ps1
# ============================================================

param(
    [string]$ArmaPath = "D:\SteamLibrary\steamapps\common\Arma 3",
    [string]$PythiaWorkshopId = "1751569185"
)

$ErrorActionPreference = "Stop"

Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  SATER SIM3D v3.0 - Installation" -ForegroundColor Cyan
Write-Host "  F1GBD / ADRASEC 77" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Verifier ARMA III
if (-not (Test-Path $ArmaPath)) {
    Write-Host "ERREUR: ARMA III non trouve a: $ArmaPath" -ForegroundColor Red
    Write-Host "Relancez avec: -ArmaPath 'C:\votre\chemin\Arma 3'" -ForegroundColor Yellow
    exit 1
}
Write-Host "[OK] ARMA III trouve: $ArmaPath" -ForegroundColor Green

# Verifier Pythia
# Chercher Pythia dans plusieurs emplacements
$PythiaFound = $false
$PythiaCandidates = @(
    "$ArmaPath\@Pythia",
    "D:\SteamLibrary\steamapps\workshop\content\107410\$PythiaWorkshopId",
    "C:\Program Files (x86)\Steam\steamapps\workshop\content\107410\$PythiaWorkshopId"
)
foreach ($c in $PythiaCandidates) {
    if (Test-Path $c) { $PythiaFound = $true; break }
}
if ($PythiaFound) {
    Write-Host "[OK] Mod Pythia trouve" -ForegroundColor Green
} else {
    Write-Host "[!!] Pythia non trouve - installez le depuis le Workshop Steam (ID: $PythiaWorkshopId)" -ForegroundColor Yellow
}

# 1. Installer @SATER_SIM
Write-Host ""
Write-Host "=== Installation @SATER_SIM ===" -ForegroundColor White
$ModDest = "$ArmaPath\@SATER_SIM"

if (Test-Path $ModDest) {
    Write-Host "Mise a jour du mod existant..." -ForegroundColor Yellow
} else {
    New-Item -ItemType Directory -Path $ModDest -Force | Out-Null
    New-Item -ItemType Directory -Path "$ModDest\Addons" -Force | Out-Null
    New-Item -ItemType Directory -Path "$ModDest\keys" -Force | Out-Null
    New-Item -ItemType Directory -Path "$ModDest\sater_code" -Force | Out-Null
}

# Copier les fichiers mod
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Copy-Item "$ScriptDir\@SATER_SIM\mod.cpp" "$ModDest\mod.cpp" -Force
Copy-Item "$ScriptDir\@SATER_SIM\meta.cpp" "$ModDest\meta.cpp" -Force
Copy-Item "$ScriptDir\@SATER_SIM\Addons\SATER_core.pbo" "$ModDest\Addons\SATER_core.pbo" -Force
# Creer $PYTHIA$ (contient "sater_code")
Set-Content -Path "$ModDest\sater_code\`$PYTHIA`$" -Value "sater_code" -NoNewline
Write-Host "[OK] `$PYTHIA`$ cree" -ForegroundColor Green

# Copier __init__.py depuis le dossier source
if (Test-Path "$ScriptDir\@SATER_SIM\sater_code\__init__.py") {
    Copy-Item "$ScriptDir\@SATER_SIM\sater_code\__init__.py" "$ModDest\sater_code\__init__.py" -Force
} else {
    Write-Host "[!!] __init__.py non trouve dans $ScriptDir\@SATER_SIM\sater_code\" -ForegroundColor Yellow
    Write-Host "     Copiez manuellement __init__.py dans $ModDest\sater_code\" -ForegroundColor Yellow
}

if (Test-Path "$ScriptDir\@SATER_SIM\keys\SATER.bikey") {
    Copy-Item "$ScriptDir\@SATER_SIM\keys\SATER.bikey" "$ModDest\keys\SATER.bikey" -Force
}
Write-Host "[OK] @SATER_SIM installe" -ForegroundColor Green

# 2. Installer la mission
Write-Host ""
Write-Host "=== Installation mission SaterSim.Altis ===" -ForegroundColor White
$MissionDest = "$ArmaPath\Missions\SaterSim.Altis"
if (-not (Test-Path $MissionDest)) {
    New-Item -ItemType Directory -Path $MissionDest -Force | Out-Null
}

$MissionSrc = "$ScriptDir\Mission\SaterSim.Altis"
Get-ChildItem $MissionSrc | ForEach-Object {
    Copy-Item $_.FullName "$MissionDest\$($_.Name)" -Force
}
Write-Host "[OK] Mission installee" -ForegroundColor Green

# 3. Generer les voix PCO
Write-Host ""
Write-Host "=== Generation voix PCO (TTS) ===" -ForegroundColor White
$TtsScript = "$ScriptDir\generate_tts.ps1"
if (Test-Path $TtsScript) {
    Write-Host "Generation des voix avec la voix Hortense..." -ForegroundColor Yellow
    & powershell -ExecutionPolicy Bypass -File $TtsScript -MissionPath $MissionDest
    Write-Host "[OK] Voix PCO generees" -ForegroundColor Green
} else {
    Write-Host "[!!] Script TTS non trouve - lancez generate_tts.ps1 manuellement" -ForegroundColor Yellow
}

# 4. Instructions lanceur
Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Installation terminee !" -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "ETAPES SUIVANTES:" -ForegroundColor White
Write-Host "  1. Ouvrez le lanceur ARMA III" -ForegroundColor Yellow
Write-Host "  2. Onglet 'Mods' -> Activez @Pythia" -ForegroundColor Yellow
Write-Host "  3. Onglet 'Mods' -> Activez @SATER_SIM" -ForegroundColor Yellow
Write-Host "  4. Lancez ARMA III" -ForegroundColor Yellow
Write-Host "  5. Solo -> Missions -> SaterSim (Altis)" -ForegroundColor Yellow
Write-Host ""
Write-Host "NOTE: Pythia doit etre installe depuis le Workshop Steam" -ForegroundColor Cyan
Write-Host "      ID Workshop: $PythiaWorkshopId" -ForegroundColor Cyan
Write-Host ""
