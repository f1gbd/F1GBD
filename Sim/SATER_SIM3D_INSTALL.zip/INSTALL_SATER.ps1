<#
    INSTALL_SATER.ps1 - Installation SATER SIM3D pour ARMA III
    F1GBD / ADRASEC 77
    
    Ce script installe automatiquement :
      - Le mod @SATER_SIM (moteur Pythia SATER)
      - La mission Solo (Missions/SaterSim.Altis.pbo)
      - La mission Multi (MPMissions/SaterSim.Altis.pbo)
    
    Compatible ARMA III standard (Steam)
    Necessite : mod Pythia (Workshop Steam ID 1751569185)
#>

# =====================================================================
# Configuration
# =====================================================================

$ErrorActionPreference = "Stop"

# Couleurs
function Write-OK    ($msg) { Write-Host "[OK] $msg" -ForegroundColor Green }
function Write-WARN  ($msg) { Write-Host "[!!] $msg" -ForegroundColor Yellow }
function Write-ERR   ($msg) { Write-Host "[XX] $msg" -ForegroundColor Red }
function Write-INFO  ($msg) { Write-Host "[..] $msg" -ForegroundColor Cyan }
function Write-TITLE ($msg) { 
    Write-Host ""
    Write-Host ("=" * 65) -ForegroundColor White
    Write-Host "  $msg" -ForegroundColor White
    Write-Host ("=" * 65) -ForegroundColor White
}

# =====================================================================
# Banniere
# =====================================================================

Clear-Host
Write-Host ""
Write-Host "  =============================================" -ForegroundColor Yellow
Write-Host "   SATER SIM3D - Installation ARMA III" -ForegroundColor Yellow
Write-Host "   Simulateur recherche balise ELT 121.5 MHz" -ForegroundColor Yellow
Write-Host "   F1GBD / ADRASEC 77 / FNRASEC" -ForegroundColor Yellow
Write-Host "  =============================================" -ForegroundColor Yellow
Write-Host ""

# =====================================================================
# Detection du dossier ARMA III
# =====================================================================

Write-TITLE "ETAPE 1 : Detection d'ARMA III"

$armaPath = $null

# Methode 1 : chemins Steam standards
$steamPaths = @(
    "C:\Program Files (x86)\Steam\steamapps\common\Arma 3",
    "C:\Program Files\Steam\steamapps\common\Arma 3",
    "D:\SteamLibrary\steamapps\common\Arma 3",
    "E:\SteamLibrary\steamapps\common\Arma 3",
    "F:\SteamLibrary\steamapps\common\Arma 3",
    "D:\Steam\steamapps\common\Arma 3",
    "E:\Steam\steamapps\common\Arma 3"
)

foreach ($p in $steamPaths) {
    if (Test-Path "$p\arma3.exe") {
        $armaPath = $p
        Write-OK "ARMA III trouve : $armaPath"
        break
    }
}

# Methode 2 : registre Steam
if (-not $armaPath) {
    try {
        $steamRoot = (Get-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Valve\Steam" -ErrorAction SilentlyContinue).InstallPath
        if ($steamRoot) {
            $tryPath = "$steamRoot\steamapps\common\Arma 3"
            if (Test-Path "$tryPath\arma3.exe") {
                $armaPath = $tryPath
                Write-OK "ARMA III trouve (registre) : $armaPath"
            }
            # Chercher dans les libraryfolders.vdf
            $libFile = "$steamRoot\steamapps\libraryfolders.vdf"
            if (Test-Path $libFile) {
                $content = Get-Content $libFile -Raw
                $matches = [regex]::Matches($content, '"path"\s+"([^"]+)"')
                foreach ($m in $matches) {
                    $libPath = $m.Groups[1].Value.Replace("\\\\", "\")
                    $tryPath = "$libPath\steamapps\common\Arma 3"
                    if (Test-Path "$tryPath\arma3.exe") {
                        $armaPath = $tryPath
                        Write-OK "ARMA III trouve (library) : $armaPath"
                        break
                    }
                }
            }
        }
    } catch {}
}

# Methode 3 : demander a l'utilisateur
if (-not $armaPath) {
    Write-WARN "ARMA III non detecte automatiquement"
    Write-Host ""
    $armaPath = Read-Host "Entrez le chemin vers ARMA III (ex: D:\SteamLibrary\steamapps\common\Arma 3)"
    $armaPath = $armaPath.Trim('"').Trim("'")
    if (-not (Test-Path "$armaPath\arma3.exe")) {
        Write-ERR "arma3.exe non trouve dans : $armaPath"
        Write-ERR "Installation annulee."
        Read-Host "Appuyez sur Entree pour quitter"
        exit 1
    }
    Write-OK "ARMA III confirme : $armaPath"
}

# =====================================================================
# Verification Pythia
# =====================================================================

Write-TITLE "ETAPE 2 : Verification du mod Pythia"

$pythiaOK = $false

# Chercher Pythia dans le Workshop
$workshopBase = Split-Path (Split-Path $armaPath)  # steamapps\common -> steamapps
$pythiaWorkshop = "$workshopBase\workshop\content\107410\1751569185"

if (Test-Path $pythiaWorkshop) {
    Write-OK "Pythia installe (Workshop) : $pythiaWorkshop"
    $pythiaOK = $true
} else {
    # Chercher dans d'autres emplacements Workshop
    $steamRoot = Split-Path (Split-Path $workshopBase)
    $libFile = "$steamRoot\steamapps\libraryfolders.vdf"
    if (Test-Path $libFile) {
        $content = Get-Content $libFile -Raw
        $matches = [regex]::Matches($content, '"path"\s+"([^"]+)"')
        foreach ($m in $matches) {
            $libPath = $m.Groups[1].Value.Replace("\\\\", "\")
            $tryPythia = "$libPath\steamapps\workshop\content\107410\1751569185"
            if (Test-Path $tryPythia) {
                Write-OK "Pythia installe (Workshop) : $tryPythia"
                $pythiaOK = $true
                break
            }
        }
    }
}

# Chercher aussi comme mod local
if (-not $pythiaOK) {
    if (Test-Path "$armaPath\@Pythia") {
        Write-OK "Pythia installe (mod local) : $armaPath\@Pythia"
        $pythiaOK = $true
    }
}

if (-not $pythiaOK) {
    Write-WARN "Pythia NON DETECTE !"
    Write-Host ""
    Write-Host "  Pythia est OBLIGATOIRE pour SATER SIM3D." -ForegroundColor Yellow
    Write-Host "  Installation via Steam Workshop :" -ForegroundColor Yellow
    Write-Host "    1. Ouvrir Steam -> ARMA III -> Workshop" -ForegroundColor White
    Write-Host "    2. Rechercher 'Pythia' (ID: 1751569185)" -ForegroundColor White
    Write-Host "    3. Cliquer 'S'abonner'" -ForegroundColor White
    Write-Host "    4. Relancer ce script apres installation" -ForegroundColor White
    Write-Host ""
    $cont = Read-Host "Continuer quand meme ? (O/N)"
    if ($cont -ne "O" -and $cont -ne "o") {
        exit 1
    }
}

# =====================================================================
# Dossier source (ou se trouve ce script)
# =====================================================================

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-INFO "Dossier source : $scriptDir"

# Verifier que les fichiers sont presents
$modSrc = "$scriptDir\@SATER_SIM"
$soloPbo = "$scriptDir\SaterSim_Solo.Altis.pbo"
$multiPbo = "$scriptDir\SaterSim_Multi.Altis.pbo"

$filesOK = $true
if (-not (Test-Path $modSrc)) { Write-ERR "Manquant : @SATER_SIM\"; $filesOK = $false }
if (-not (Test-Path $soloPbo)) { Write-ERR "Manquant : SaterSim_Solo.Altis.pbo"; $filesOK = $false }
if (-not (Test-Path $multiPbo)) { Write-ERR "Manquant : SaterSim_Multi.Altis.pbo"; $filesOK = $false }

if (-not $filesOK) {
    Write-ERR "Fichiers source manquants. Verifiez le contenu du ZIP."
    Read-Host "Appuyez sur Entree pour quitter"
    exit 1
}
Write-OK "Fichiers source presents"

# =====================================================================
# Installation du mod @SATER_SIM
# =====================================================================

Write-TITLE "ETAPE 3 : Installation du mod @SATER_SIM"

$modDst = "$armaPath\@SATER_SIM"

if (Test-Path $modDst) {
    Write-WARN "Le mod @SATER_SIM existe deja - mise a jour..."
    Remove-Item -Recurse -Force $modDst
}

Copy-Item -Recurse -Force $modSrc $modDst
Write-OK "Mod copie : $modDst"

# Verifier les fichiers critiques
$criticalFiles = @(
    "$modDst\Addons\SATER_core.pbo",
    "$modDst\sater_code\__init__.py",
    "$modDst\sater_code\`$PYTHIA`$",
    "$modDst\mod.cpp"
)
$allPresent = $true
foreach ($cf in $criticalFiles) {
    if (-not (Test-Path $cf)) {
        Write-ERR "Fichier manquant : $cf"
        $allPresent = $false
    }
}
if ($allPresent) {
    Write-OK "Tous les fichiers du mod presents"
} else {
    Write-WARN "Certains fichiers manquent - le mod pourrait ne pas fonctionner"
}

# =====================================================================
# Installation mission SOLO
# =====================================================================

Write-TITLE "ETAPE 4 : Installation mission SOLO"

$missionsSolo = "$armaPath\Missions"
if (-not (Test-Path $missionsSolo)) {
    New-Item -ItemType Directory -Path $missionsSolo -Force | Out-Null
    Write-INFO "Dossier Missions\ cree"
}

# Supprimer l'ancienne mission si presente
$oldSolo = "$missionsSolo\SaterSim.Altis.pbo"
if (Test-Path $oldSolo) {
    Remove-Item -Force $oldSolo
    Write-INFO "Ancienne mission solo supprimee"
}
# Supprimer aussi un eventuel dossier
$oldSoloDir = "$missionsSolo\SaterSim.Altis"
if (Test-Path $oldSoloDir) {
    Remove-Item -Recurse -Force $oldSoloDir
    Write-INFO "Ancien dossier mission solo supprime"
}

Copy-Item -Force $soloPbo $oldSolo
Write-OK "Mission solo installee : $oldSolo"

# =====================================================================
# Installation mission MULTI
# =====================================================================

Write-TITLE "ETAPE 5 : Installation mission MULTI"

$missionsMp = "$armaPath\MPMissions"
if (-not (Test-Path $missionsMp)) {
    New-Item -ItemType Directory -Path $missionsMp -Force | Out-Null
    Write-INFO "Dossier MPMissions\ cree"
}

# Supprimer l'ancienne mission si presente (PBO et/ou dossier)
$oldMulti = "$missionsMp\SaterSim.Altis.pbo"
$oldMultiDir = "$missionsMp\SaterSim.Altis"
if (Test-Path $oldMulti) {
    Remove-Item -Force $oldMulti
    Write-INFO "Ancien PBO multi supprime"
}
if (Test-Path $oldMultiDir) {
    Remove-Item -Recurse -Force $oldMultiDir
    Write-INFO "Ancien dossier multi supprime (evite doublon)"
}

Copy-Item -Force $multiPbo $oldMulti
Write-OK "Mission multi installee : $oldMulti"

# =====================================================================
# Resume
# =====================================================================

Write-TITLE "INSTALLATION TERMINEE"

Write-Host ""
Write-Host "  Fichiers installes :" -ForegroundColor White
Write-Host "    Mod  : $modDst" -ForegroundColor Green
Write-Host "    Solo : $missionsSolo\SaterSim.Altis.pbo" -ForegroundColor Green
Write-Host "    Multi: $missionsMp\SaterSim.Altis.pbo" -ForegroundColor Green
Write-Host ""
Write-Host "  Structure ARMA III :" -ForegroundColor White
Write-Host "    $armaPath\" -ForegroundColor Gray
Write-Host "    +-- @Pythia\            (mod Workshop)" -ForegroundColor Gray
Write-Host "    +-- @SATER_SIM\         (mod SATER)" -ForegroundColor Gray
Write-Host "    |   +-- Addons\SATER_core.pbo" -ForegroundColor Gray
Write-Host "    |   +-- sater_code\__init__.py" -ForegroundColor Gray
Write-Host "    +-- Missions\" -ForegroundColor Gray
Write-Host "    |   +-- SaterSim.Altis.pbo  (solo)" -ForegroundColor Gray
Write-Host "    +-- MPMissions\" -ForegroundColor Gray
Write-Host "        +-- SaterSim.Altis.pbo  (multi 4 joueurs)" -ForegroundColor Gray
Write-Host ""

Write-TITLE "LANCEMENT D'ARMA III"

Write-Host ""
Write-Host "  1. Ouvrir le LANCEUR ARMA III" -ForegroundColor White
Write-Host "  2. Onglet MODS -> Activer :" -ForegroundColor White
Write-Host "       [x] Pythia" -ForegroundColor Yellow
Write-Host "       [x] SATER SIM3D" -ForegroundColor Yellow
Write-Host "  3. Mode SOLO :" -ForegroundColor White
Write-Host "       Solo -> Missions -> SaterSim (Altis)" -ForegroundColor Cyan
Write-Host "  4. Mode MULTI (LAN) :" -ForegroundColor White
Write-Host "       Multijoueur -> Creer -> SaterSim (Altis)" -ForegroundColor Cyan
Write-Host "       4 slots : Op. Yagi 1/2/3 + PCO" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Commandes en jeu :" -ForegroundColor White
Write-Host "       R = Relevement goniometrique" -ForegroundColor Yellow
Write-Host "       Regard joueur = direction antenne Yagi" -ForegroundColor Yellow
Write-Host "       Carte -> UAV -> Controler = pilotage drone" -ForegroundColor Yellow
Write-Host ""

# =====================================================================
# Proposer de copier sur une 2eme machine (multi LAN)
# =====================================================================

Write-Host "  -------------------------------------------" -ForegroundColor DarkGray
$copy2 = Read-Host "  Copier pour une 2eme machine LAN ? (O/N)"

if ($copy2 -eq "O" -or $copy2 -eq "o") {
    Write-Host ""
    Write-INFO "Preparation du package LAN..."
    
    $lanDst = "$scriptDir\SATER_LAN_Client"
    if (Test-Path $lanDst) { Remove-Item -Recurse -Force $lanDst }
    New-Item -ItemType Directory -Path $lanDst -Force | Out-Null
    New-Item -ItemType Directory -Path "$lanDst\@SATER_SIM" -Force | Out-Null
    New-Item -ItemType Directory -Path "$lanDst\MPMissions" -Force | Out-Null
    
    Copy-Item -Recurse -Force $modDst\* "$lanDst\@SATER_SIM\"
    Copy-Item -Force $multiPbo "$lanDst\MPMissions\SaterSim.Altis.pbo"
    
    # Creer un mini script pour le client
    @"
# INSTALL_CLIENT.ps1 - Installation SATER client LAN
`$arma = Read-Host "Chemin ARMA III (ex: D:\SteamLibrary\steamapps\common\Arma 3)"
`$arma = `$arma.Trim('"')
if (-not (Test-Path "`$arma\arma3.exe")) { Write-Host "ARMA non trouve !"; exit 1 }
Copy-Item -Recurse -Force "`$PSScriptRoot\@SATER_SIM" "`$arma\@SATER_SIM"
Copy-Item -Force "`$PSScriptRoot\MPMissions\SaterSim.Altis.pbo" "`$arma\MPMissions\SaterSim.Altis.pbo"
Write-Host "Installation client OK !" -ForegroundColor Green
Write-Host "Activer @Pythia + @SATER_SIM dans le lanceur ARMA" -ForegroundColor Yellow
Read-Host "Entree pour quitter"
"@ | Out-File -Encoding UTF8 "$lanDst\INSTALL_CLIENT.ps1"
    
    Write-OK "Package client cree : $lanDst\"
    Write-Host "  Copiez ce dossier sur la machine client (cle USB ou reseau)" -ForegroundColor Cyan
    Write-Host "  Puis lancez INSTALL_CLIENT.ps1 sur le client" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "  73 de F1GBD - ADRASEC 77" -ForegroundColor Yellow
Write-Host ""
Read-Host "Appuyez sur Entree pour quitter"
